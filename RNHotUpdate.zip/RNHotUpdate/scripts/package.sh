#!/usr/bin/env bash


bundleModel=$1;
if [ $bundleModel = "dev" ]; then
    echo "打的包为联调模式:dev = true"
    dev=true;
elif [ $bundleModel = "dis" ]; then
    echo "打的包为离线模式 dev = false"
    dev=false;
else
    echo '缺少必要参数'
    echo "用法: $0 dev|dis"
    exit 1;
fi;

#开始打包
toPath="./output/IOS/NormalBundle"

rm -r -f $toPath

#TODO: 修改图片资源路径
mkdir -p $toPath

react-native bundle --entry-file index.ios.js --bundle-output "${toPath}/RNHotUpdate.jsbundle" --platform ios --assets-dest ${toPath} --dev dev
result=$?
if [ $result -eq 0 ]; then
   echo "RN 打包命令执行成功"
else
   echo "RN 打包命令执行失败,请检查上面的错误信息 如果错误在/node_modules/.....，很可能是依赖库未更新，请npm update, 还不行的话，请删除node_modules文件夹，重新npm install"
   exit 1;
fi

exit 0
