//
//  AppDelegate.h
//  RNHotUpdate
//
//  Created by Dongdong on 17/3/7.
//  Copyright © 2017年 com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

